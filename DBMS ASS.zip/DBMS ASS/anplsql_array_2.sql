--anplsql_array_2.sql : Write a program in PL/SQL to sort numbers in ascending order using Bubble Sort Method
DECLARE 
   type aarray  IS VARRAY(10) of INTEGER;
   type idarray IS VARRAY(10) OF INTEGER ;
   
   a aarray;  
   id idarray;
  n INTEGER;
  flag INTEGER;
  m INTEGER;
  t INTEGER;
  pass1 INTEGER;
   BEGIN 
   a:=aarray(100,90,80,70,60,50,40,30,20,10);
   id:=idarray(1,2,3,4,5,6,7,8,9,10);
  n := a.count; 
dbms_output.put_line('Unsorted List');
dbms_output.put_line('Number'||chr(9)||'Index');
    	for i in 1..n LOOP 
    	dbms_output.put_line(a(i)||chr(9)||id(i));
	END LOOP;
--Bubble Sort Program starts
flag:=0;
m:=n;
pass1:=0;
	while(flag=0) LOOP
	flag:=1;
	m:=m-1;
	pass1:=pass1+1;
	FOR i in  1..m LOOP
		if(a(i)>a(i+1)) THEN
        t:=a(i);
		a(i):=a(i+1);
		a(i+1):=t;
		t:=id(i);
		id(i):=id(i+1);
		id(i+1):=t;
		flag:=0;
		
		END IF;
	END LOOP;
	dbms_output.put_line('Pass='||pass1);
	dbms_output.put_line('Number'||chr(9)||'Index');
	FOR i in 1..n  LOOP
	dbms_output.put_line(a(i)||chr(9)||id(i));
    END LOOP;

	END LOOP; 
dbms_output.put_line('Sorted List');
	FOR i in 1..n  LOOP
	dbms_output.put_line(a(i)||chr(9)||id(i));
	END LOOP;

   END; 
/