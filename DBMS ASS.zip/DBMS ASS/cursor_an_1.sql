--cursor_an_1.sql : Write PL/SQL code to insert eid, name, basic data in table salary
--Calculate da, hra, gross, pf, net
DECLARE
	da number(6);
	hra number(6);
	gross number(6);
	pf number(6);
	net number(6);
BEGIN
	INSERT INTO salary(eid, name,basic) VALUES(1,'S.K.Patra',80000);
	INSERT INTO salary(eid, name,basic) VALUES(2,'D.K. Sen',100000);
	INSERT INTO salary(eid, name,basic) VALUES(3,'M.K.Das',200000);
	INSERT INTO salary(eid, name,basic) VALUES(4,'B.K.Mathur',150000);
	INSERT INTO salary(eid, name,basic) VALUES(5,'B.Nayek',30000);
	INSERT INTO salary(eid, name,basic) VALUES(6,'S. Fulmali',40000);
	INSERT INTO salary(eid, name,basic) VALUES(7,'S.Thapa',25000);
	update salary set da=.06*basic; --calculating da @6% of Basic
	update salary set hra=.15*basic where .15*basic<=15000; --calculating hra
	update salary set hra=15000 where .15*basic>15000; --calculating hra
	update salary set gross=basic+da+hra; --Calculating gross
	update salary set pf=.0833*(basic+da); --calculting pf
	update salary set net=gross-pf;--calculating net
	dbms_output.put_line('Table updated');
	commit;
END;
/
	