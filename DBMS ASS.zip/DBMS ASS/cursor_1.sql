--cursor_1.sql : Write a program in PL/SQL to use cursor
DECLARE 
   name1 table1.name%type;    -- customers.id%type; 
   email1 table1.email%type;  --c_name customers.name%type; 
   mobile1 table1.mobile%type; --c_addr customers.address%type; 
   CURSOR my_cursor is  
      SELECT name, email, mobile FROM table1; 
BEGIN 
   OPEN my_cursor;
   LOOP 
   FETCH my_cursor into name1, email1, mobile1; 
      EXIT WHEN my_cursor%notfound; 
    dbms_output.put_line(name1 || ' : ' || email1 || ' :  ' || mobile1); 
   END LOOP; 
   CLOSE my_cursor; 
END; 
/
