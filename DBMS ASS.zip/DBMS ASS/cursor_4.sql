--cursor_4.sql : Write cursor program in PL/SQL to display data from table1
DECLARE 
	name1 table1.name%type;
	email1 table1.email%type;
	mobile1 table1.mobile%type;
	cnt INTEGER :=0; --To count number of records in table1
	CURSOR MYCURSOR IS SELECT name, email, mobile FROM table1; -- Defining cursor as MYCURSOR
BEGIN
	dbms_output.put_line('Data Available in table1');
	OPEN MYCURSOR;  -- opening MYCURSor in the program
	LOOP
	FETCH MYCURSOR INTO name1, email1,mobile1;
	EXIT WHEN MYCURSOR%NOTFOUND;
	dbms_output.put_line(name1||chr(9)||email1||chr(9)||mobile1);
	cnt:=cnt+1;
	END LOOP;
	dbms_output.put_line('Total number of records in table1='||cnt);
	close MYCURSOR;
END;
/
