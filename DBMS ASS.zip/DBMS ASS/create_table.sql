--create_table.sql : Write a program in PL/SQL to create a table called as table1
DECLARE
	
BEGIN
	CREATE TABLE table1(name varchar2(20), email varchar2(20), mobile varchar2(15));
    dbms_output.put_line(table1|| ' created successfully...');
END;
/