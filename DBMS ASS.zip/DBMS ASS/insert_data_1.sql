--insert_data_1.sql: Write a program in PL/SQL to insert data
--in a table
DECLARE
	
	nrec INTEGER :=0;
BEGIN
	INSERT INTO table1(name,email,mobile) VALUES('Asoke Nath','asoke@gmail.com',8583980490);
	nrec :=nrec+1;
	INSERT INTO table1(name,email,mobile) VALUES('Mala Nath','malanath@gmail.com',898381460);
	nrec :=nrec+1;
	INSERT INTO table1(name,email,mobile) VALUES('Joyshree Nath','joyshree@gmail.com',8777741625);
	nrec :=nrec+1;
	INSERT INTO table1(name,email,mobile) VALUES('Alivia Chowdhuri','alivia@gmail.com',8583980490);
	nrec :=nrec+1;
	INSERT INTO table1(name,email,mobile) VALUES('Sunit Chowdhury','sumit@gmail.com',8777741625);
	nrec :=nrec+1;
	COMMIT;
	dbms_output.put_line('Total number of Records added='||nrec);
END;
/
	