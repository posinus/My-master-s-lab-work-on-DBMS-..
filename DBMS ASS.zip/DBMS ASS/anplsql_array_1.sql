DECLARE 
   type namesarray IS VARRAY(5) OF VARCHAR(10);
   type basicarray IS VARRAY(5) OF NUMBER(6) ;
   type daarray IS VARRAY(5) OF NUMBER(6) ;
   type hraarray IS VARRAY(5) OF NUMBER(6) ;
   type grossarray IS VARRAY(5) OF NUMBER(6) ;
   type eidarray IS VARRAY(5) OF NUMBER(6) ;
   type pfarray IS VARRAY(5) OF  NUMBER(6);
   type netarray IS VARRAY(5)  OF  NUMBER(6);
   name namesarray;  
   eid  eidarray;
   basic_pay basicarray;
   da daarray;
   hra hraarray;
   gross grossarray;
   pf  pfarray;
   net netarray;
   n INTEGER;
   BEGIN 
   eid :=eidarray(1,2,3,4,5);
   name := namesarray('Anjan','Sneha','Srijan', 'Ayan', 'Dipak'); 
   basic_pay:= basicarray(50000,100000,40000,150000,75000); 
  da :=daarray(0,0,0,0,0);
  hra :=hraarray(0,0,0,0,0);
  gross :=grossarray(0,0,0,0,0);
  pf :=pfarray(0,0,0,0,0);
  net :=netarray(0,0,0,0,0);
  n := eid.count; 
  dbms_output.put_line('Eid'||chr(9)||'Name'||chr(9)||'Basic'||chr(9)||'DA'||chr(9)||'HRA'||chr(9)||'GROSS'||chr(9)||'PF'||chr(9)||'NETPAY');
      	for i in 1..n LOOP 
  	 da(i) :=.06*basic_pay(i);
  	 hra(i) :=.16*basic_pay(i);
		IF(hra(i)>15000) THEN
		hra(i) :=15000;
		END IF;
   	gross(i) :=basic_pay(i)+da(i)+hra(i);
                    pf(i) :=.0833*(basic_pay(i)+da(i));
                    net(i) :=gross(i)-pf(i);
   	dbms_output.put_line(eid(i)||chr(9)||name(i)||chr(9)||basic_pay(i)||chr(9)||da(i)||chr(9)||hra(i)||chr(9)||gross(i)||chr(9)||pf(i)||chr(9)||net(i));
   	END LOOP; 
   END; 
/