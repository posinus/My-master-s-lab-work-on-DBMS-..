//anplsql6.sql : write plsql code to insert data in a table
DECLARE
	name1 varchar(25):=&name1;
	email1 varchar(25):=&email1;
	mobile1 varchar(10):=&mobile1;
	salary1 number(10):=&salary1;
	
BEGIN
	insert into table1(name,email,mobile,salary)  values(name1,email1,mobile1,salary1);
END;
/