--cursor_program_2.sql : Write cursor program in PL/SQL to store data in 1-dim array 
--and then display data on screen
DECLARE
	name1 table1.name%type;
	email1 table1.email%type;
	mobile1 table1.mobile%type;
	TYPE namesarray IS VARRAY(5) of VARCHAR2(20);
	TYPE emailsarray IS VARRAY(5) of VARCHAR2(20);
	TYPE mobilesarray IS VARRAY(5) of VARCHAR2(15);
	name2 namesarray;
	email2 emailsarray;
	mobile2 mobilesarray;
	i INTEGER;
	CURSOR MYCURSOR  IS SELECT name,email,mobile FROM table1;
	nct INTEGER :=0;
	
BEGIN
    name2 :=namesarray(' ',' ', ' ', ' ', ' ') ;
	email2 :=emailsarray(' ',' ', ' ', ' ', ' ') ;
	mobile2 :=mobilesarray(' ',' ', ' ', ' ', ' ') ;

	OPEN MYCURSOR;
	FOR i IN 1..3 
	LOOP
		FETCH MYCURSOR INTO name1,email1,mobile1;
	    name2(i)  :=name1;
		email2(i) :=email1;
		mobile2(i) :=mobile1;
	END LOOP;
	CLOSE MYCURSOR;
	FOR i in 1..3
	LOOP
	dbms_output.put_line(name2(i) ||' : '||email2(i)||' : '||mobile2(i));
	END LOOP;
END;
/