--cursor_program_1.sql : Write cursor program in PL/SQL to to display data table1 on screen
DECLARE
	name1 table1.name%type;
	email1 table1.email%type;
	mobile1 table1.mobile%type;
	CURSOR MYCURSOR  IS SELECT name,email,mobile FROM table1;
	nct INTEGER :=0;
	
BEGIN
	OPEN MYCURSOR;
	LOOP
	FETCH MYCURSOR INTO name1,email1,mobile1;
	EXIT WHEN MYCURSOR%NOTFOUND;
	dbms_output.put_line(name1 ||' : '||email1||' : '||mobile1);
	nct :=nct+1;
	END LOOP;
	dbms_output.put_line('Total number of records found='||nct);
END;
/
