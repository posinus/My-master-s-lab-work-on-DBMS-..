--anplsql_2.sql : Write PL/SQL program to use if-then-elsif-else statement
--input roll, total and calculate grade
DECLARE
i number;
t number;
r number;
grade varchar2(5);
	BEGIN
	r:=&r;
	t:=&t;
	/* Calculattion of Grade */
		IF(t>=70) THEN
		grade:='A';
		ELSIF(t>=60) THEN
		grade:='B';
		ELSIF(t>=50) THEN
		grade:='C';
		ELSIF(t>=400) THEN
		grade:='D';
		ELSE
		grade:='F';
		end IF;
	dbms_output.put_line('Roll='||r||' Total='||t||' Grade='||grade);
	END;
/