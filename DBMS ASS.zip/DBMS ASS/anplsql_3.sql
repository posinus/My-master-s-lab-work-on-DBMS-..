/*anplsql_3.sql : Write PL/SQL Program to use while loop */
DECLARE
a number(3) :=&a;
b number(3) :=&b;
h number(3);
lc number(3);
x number(3);
y number(3);
r number(3);
	BEGIN
	/* To calculate hcf of 2 numbers */
	x:=a;
	y:=b;
	r:=mod(x,y);
	while r !=0 loop
	x:=y;
	y:=r;
	r:=mod(x,y);
	end loop;
	h:=y;
	--To calculate lcm
	lc:=a*b/h;
	dbms_output.put_line('HCF('||a||','||b||')='||h);
	dbms_output.put_line('LCM('||a||','||b||')='||lc);
	END;	
/