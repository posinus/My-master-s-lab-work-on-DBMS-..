--anplsql_6.sql : Write PL/SQL code to calculate (i) HCF, (ii) LCM of 2 numbers
DECLARE
	a INTEGER :=&a;
	b INTEGER :=&b;
	x INTEGER;
	y INTEGER;
	h INTEGER;
	lc INTEGER;
	r INTEGER;
BEGIN
	--To calculate hcf
	x :=a;
	y :=b;
	r :=mod(x,y);
	while(r !=0) LOOP
	x :=y;
	y :=r;
	r :=mod(x,y);
	END LOOP;
	h:=y;
	--To calculate lcm
	lc:=a*b/h;
	dbms_output.put_line('HCF('||a||','||b||')='||h);
	dbms_output.put_line('LCM('||a||','||b||')='||lc);
END;

