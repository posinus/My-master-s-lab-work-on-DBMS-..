//anplsql5.sql : write plsql code to create a table
DECLARE
	a number(5) :=&a;
	b number(5) :=&b;
	s number(5);
	av number(5);
BEGIN
	s:=a+b;
	av:=s/2;
	dbms_output.put_line('a='||a||' b='||b||' a+b='||s|| ' avg='||av);
END;
/

	