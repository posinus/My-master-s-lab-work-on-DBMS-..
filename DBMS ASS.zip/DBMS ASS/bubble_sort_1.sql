--bubble_sort_1.sql : Write a program in PL/SQL to implement
--Bubble sort algorithm to sort 10 numbers in ascending order
DECLARE
TYPE aarrays IS VARRAY(10) of INTEGER;
i INTEGER;
t INTEGER;
n INTEGER :=5;
m INTEGER;
pass1 INTEGER;
nstep INTEGER;
flag INTEGER;
a aarrays;
j INTEGER;
BEGIN
	a :=aarrays(100,90,80,70,60,50,40,30,20,10);
	dbms_output.put('Unsorted List==>');
	n:=10;
	FOR i IN 1..n
	LOOP
	dbms_output.put(a(i)|| ' ');
	END LOOP;
	dbms_output.put_line(' ');
	--Bubble sort routine starts
	flag :=0;
	pass1 :=0;
	nstep :=0;
	m:=n;
	WHILE(flag=0)
	LOOP
	flag :=1;
	m:=m-1;
	pass1:=pass1+1;
		FOR i IN 1..m
		LOOP
		nstep :=nstep+1;
			IF(a(i)>a(i+1))
			THEN
			t :=a(i);
			a(i):=a(i+1);
			a(i+1):=t;
			flag :=0;
			END IF;
		END LOOP;
	dbms_output.put('Pass='||pass1||' nstep='||nstep|| ' numbers==> ');
		FOR j IN 1..n
		LOOP
		dbms_output.put(a(j)||' ');
		END LOOP;
	dbms_output.put_line(' ');
	END LOOP;
	dbms_output.put_line('Bubble Sort Routine Ends here--->');
	dbms_output.put_line('Sorted List==>');
	FOR j IN 1..n
	LOOP
	dbms_output.put_line(a(j)|| ' ');
	END LOOP;
END;
/
