--cursor_1.sql : Write a program in PL/SQL to use cursor
DECLARE 
   name1 table1.name%type;    -- customers.id%type; 
   email1 table1.email%type;  --c_name customers.name%type; 
   mobile1 table1.mobile%type; --c_addr customers.address%type; 
   TYPE namesarray IS VARRAY(5) OF VARCHAR2(20);
   TYPE emailsarray IS VARRAY(5) OF VARCHAR2(20);
   TYPE mobilesarray IS VARRAY(5) OF VARCHAR2(10);


   name2 namesarray;
   email2 emailsarray;
   mobile2 mobilesarray;
   i INTEGER;
   CURSOR my_cursor is  
      SELECT name, email, mobile FROM table1; 
BEGIN 
   name2:=namesarray(' ',' ',' ',' ',' ');
   email2:=emailsarray(' ',' ',' ',' ',' ');
   mobile2:=mobilesarray(' ',' ',' ',' ',' ');
   
   OPEN my_cursor;
   FOR i in 1..5 LOOP 
     FETCH my_cursor into name1, email1, mobile1; 
     name2(i):=name1;
	 email2(i):=email1;
	 mobile2(i):=mobile1;
   END LOOP;
   --To display all data of your TABLE
   
   for i in 1..5 LOOP
   dbms_output.put_line('Name('||i||')='||name2(i)||' Email('||i||')='||email2(i)||' Mobile('||i||')='||mobile2(i));
   End LOOP;
      CLOSE my_cursor; 
END; 
/
