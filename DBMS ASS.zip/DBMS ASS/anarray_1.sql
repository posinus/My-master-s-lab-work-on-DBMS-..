--anarray_1.sql : Write a program to use 1-dim array
DECLARE 
	TYPE aarrays IS VARRAY(5) of number(3);
	a aarrays;
	i number(2);
	s number(3);
	BEGIN
	a :=aarrays(10,20,30,40,50);
	s:=0;
	FOR i in 1..5  LOOP
	s:=s+a(i);
	END LOOP;
	dbms_output.put_line('Sum='||s);
	END;
	/
