--cursor_an_2.sql : Write a program in PL/SQL to read data from salary table and store 
--data in array. display all data on screen
DECLARE
	eid1 salary.eid%type;
	name1 salary.name%type;
	basic1 salary.basic%type;
	da1 salary.da%type;
	hra1 salary.hra%type;
	gross1 salary.gross%type;
	pf1 salary.pf%type;
	net1 salary.net%type;
	TYPE eidarray IS VARRAY(7) OF NUMBER(3);
	TYPE namearray IS VARRAY(7) OF VARCHAR2(20);
	TYPE basicarray IS VARRAY(7) OF NUMBER(6);
	TYPE daarray IS VARRAY(7) OF NUMBER(6);
	TYPE hraarray IS VARRAY(7) OF NUMBER(6);
	TYPE grossarray IS VARRAY(7) OF NUMBER(6);
	TYPE pfarray IS VARRAY(7) OF NUMBER(6);
	TYPE netarray IS VARRAY(7) OF NUMBER(6);
	eid2 eidarray;
	name2 namearray;
	basic2 basicarray;
	da2 daarray;
	hra2 hraarray;
	gross2 grossarray;
	pf2 pfarray;
	net2 netarray;
	n NUMBER :=7;
	tbasic number(6) :=0;
	tda number(6) :=0;
	thra number(6) :=0;
	tgross number(6) :=0;
	tpf number(6) :=0;
	tnet number(6) :=0;
	i INTEGER;
	high1 INTEGER;
	low1 INTEGER;
	i1 INTEGER;
	j1 INTEGER;
	CURSOR SALARY_CURSOR IS 
		SELECT eid,name,basic,da,hra,gross,pf,net FROM salary;  --Defining SALARY_CURSOR
	BEGIN
		eid2 :=eidarray(0,0,0,0,0,0,0);
		name2:=namearray(' ',' ', ' ', ' ', ' ', ' ', ' ') ;
		basic2 :=basicarray(0,0,0,0,0,0,0);
		da2 :=daarray(0,0,0,0,0,0,0);
		hra2 :=hraarray(0,0,0,0,0,0,0);
		gross2 :=grossarray(0,0,0,0,0,0,0);
		pf2 :=pfarray(0,0,0,0,0,0,0);
		net2 :=netarray(0,0,0,0,0,0,0);
		OPEN SALARY_CURSOR;
		FOR i IN 1..n
		LOOP
		FETCH SALARY_CURSOR INTO eid1,name1,basic1,da1,hra1,gross1,pf1,net1; --Copying data to temp LOCALOCK
		--Copying all data in 1-dim array
		eid2(i):=eid1;
		name2(i):=name1;
		basic2(i):=basic1;
		da2(i):=da1;
		hra2(i):=hra1;
		gross2(i):=gross1;
		pf2(i):=pf1;
		net2(i):=net1;
		tbasic :=tbasic+basic2(i);
		tda :=tda+da2(i);
		thra :=thra+hra2(i);
		tgross :=tgross+gross2(i);
		tpf :=tpf+pf2(i);
		tnet :=tnet+net2(i);
		END LOOP;
	--To calculate highest net salary and lowest net salary
	high1 :=net2(1);
	i1 :=1;
	j1 :=1;
	low1 :=net2(1);
		FOR i IN 2..7
		LOOP
			IF(net2(i)>high1) THEN
			high1 :=net2(i);
			i1 :=i;
			END IF;
			IF(net2(i)<low1) THEN
			low1 :=net2(i);
			j1 :=i;
			END IF;

		END LOOP;
	dbms_output.put_line('Highest Net Pay='||high1)	;
	dbms_output.put_line('Lowest Net Pay='||low1)	;
	
	dbms_output.put_line('Total Basic pay='||tbasic);
	dbms_output.put_line('Total DA='||tda);
	dbms_output.put_line('Total HRA='||thra);
	dbms_output.put_line('Total Gross pay='||tgross);
	dbms_output.put_line('Total PF='||tpf);
	dbms_output.put_line('Total Net Pay='||tnet);
	END;
	/
		
	
	
	
	