--an_plsql_1.sql : Write a simple PL/SQL Code to input
--a,b and then calculate (i) sum, (ii) difference, (iii) product
--(iv) division of 2 numbers
DECLARE
a number(6):=&a;
b number(6):=&b;
s number(6);
diff number(6);
prod number(6);
dv number(6);
BEGIN
s :=a+b;
diff :=a-b;
prod :=a*b;
dv :=a/b;
dbms_output.put_line(a||'+'||b||'='||s);
dbms_output.put_line(a||'-'||b||'='||diff);
dbms_output.put_line(a||'*'||b||'='||prod);
dbms_output.put_line(a||'/'||b||'='||dv);
END;
/


